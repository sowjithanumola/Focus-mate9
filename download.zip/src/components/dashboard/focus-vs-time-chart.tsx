'use client';

import { useMemo } from 'react';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { format, eachDayOfInterval, startOfDay } from 'date-fns';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import type { StudyLog } from '@/lib/types';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { Timestamp } from 'firebase/firestore';

const chartConfig = {
  timeSpent: {
    label: 'Time Spent',
    color: 'hsl(var(--chart-1))',
  },
  averageFocus: {
    label: 'Avg. Focus',
    color: 'hsl(var(--chart-2))',
  },
} satisfies ChartConfig;

// Helper to convert Firestore Timestamp to Date
const toDate = (date: Date | Timestamp): Date => {
    return date instanceof Timestamp ? date.toDate() : date;
}

export function FocusVsTimeChart({ logs }: { logs: StudyLog[] }) {
  const chartData = useMemo(() => {
    if (logs.length === 0) return [];

    const dateToLogs = new Map<string, StudyLog[]>();
    logs.forEach(log => {
        const day = format(startOfDay(toDate(log.date)), 'yyyy-MM-dd');
        if (!dateToLogs.has(day)) {
            dateToLogs.set(day, []);
        }
        dateToLogs.get(day)!.push(log);
    });

    const dates = logs.map(log => toDate(log.date));
    const minDate = new Date(Math.min(...dates.map(date => date.getTime())));
    const maxDate = new Date(Math.max(...dates.map(date => date.getTime())));

    const interval = eachDayOfInterval({ start: minDate, end: maxDate });

    return interval.map(date => {
        const dayKey = format(date, 'yyyy-MM-dd');
        const dayLogs = dateToLogs.get(dayKey) || [];
        
        const timeSpent = dayLogs.reduce((acc, log) => acc + log.timeSpent, 0);
        const focusMapping = { Low: 1, Medium: 2, High: 3 };
        const totalFocus = dayLogs.reduce((acc, log) => acc + focusMapping[log.focusLevel], 0);
        const averageFocus = dayLogs.length > 0 ? totalFocus / dayLogs.length : 0;
        
        return {
            date: format(date, 'MMM d'),
            timeSpent: timeSpent,
            averageFocus: parseFloat(averageFocus.toFixed(2)),
        };
    });
  }, [logs]);

  return (
    <Card className="lg:col-span-4">
      <CardHeader>
        <CardTitle className="font-headline">Activity Overview</CardTitle>
        <CardDescription>Time spent and average focus level per day.</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ChartContainer config={chartConfig} className="min-h-[350px] w-full">
            {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={350}>
                    <BarChart data={chartData}>
                        <CartesianGrid vertical={false} strokeDasharray="3 3" />
                        <XAxis
                        dataKey="date"
                        stroke="#888888"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        />
                        <YAxis
                        yAxisId="left"
                        stroke="#888888"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value} min`}
                        />
                        <YAxis
                        yAxisId="right"
                        orientation="right"
                        stroke="hsl(var(--chart-2))"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value}`}
                        />
                        <ChartTooltip
                            content={<ChartTooltipContent
                                formatter={(value, name) => {
                                    if (name === 'timeSpent') {
                                        return `${value} min`;
                                    }
                                    return value;
                                }}
                            />}
                            cursor={{fill: 'hsl(var(--accent) / 0.2)'}}
                        />
                        <Bar yAxisId="left" dataKey="timeSpent" fill="var(--color-timeSpent)" radius={[4, 4, 0, 0]} name="timeSpent" />
                        <Bar yAxisId="right" dataKey="averageFocus" fill="var(--color-averageFocus)" radius={[4, 4, 0, 0]} name="averageFocus" />
                    </BarChart>
                </ResponsiveContainer>
            ) : (
                 <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                    No data to display for the selected period.
                </div>
            )}
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
