'use client';

import type { MonthlyReport, StudyLog } from '@/lib/types';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Icons } from '@/components/icons';
import { format } from 'date-fns';
import { toDate } from '@/lib/utils';

interface ReportDisplayProps {
  report: MonthlyReport | null;
  studyLogs: StudyLog[];
  month: number;
  year: number;
}

const focusVariantMap: { [key: string]: 'default' | 'secondary' | 'destructive' } = {
    High: 'default',
    Medium: 'secondary',
    Low: 'destructive',
  };

export function ReportDisplay({ report, studyLogs, month, year }: ReportDisplayProps) {
  if (report === null) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground">
          No report found for {format(new Date(year, month), 'MMMM yyyy')}.
          <br />
          {studyLogs.length > 0
            ? 'Try generating a new one!'
            : 'You have no study logs for this period.'}
        </CardContent>
      </Card>
    );
  }

  const lowFocusDays = (report?.lowFocusDays || []).map(dateStr => toDate(dateStr)).sort((a,b) => a.getTime() - b.getTime());

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-2xl">
          Report for {format(new Date(year, month), 'MMMM yyyy')}
        </CardTitle>
        <CardDescription>
          An AI-powered analysis of your study habits and achievements for the selected month.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <Icons.FileText className="h-4 w-4" />
          <AlertTitle className="font-semibold">Performance Summary</AlertTitle>
          <AlertDescription>{report.performanceSummary}</AlertDescription>
        </Alert>

        <Alert>
          <Icons.CheckCircle className="h-4 w-4" />
          <AlertTitle className="font-semibold">Achievement Summary</AlertTitle>
          <AlertDescription>{report.achievementSummary}</AlertDescription>
        </Alert>

        <Alert>
          <Icons.Sparkles className="h-4 w-4" />
          <AlertTitle className="font-semibold">Improvement Suggestions</AlertTitle>
          <AlertDescription>{report.improvementSuggestions}</AlertDescription>
        </Alert>
        
        {lowFocusDays.length > 0 && (
            <Card>
                <CardHeader>
                    <CardTitle className="text-lg">Low-Focus Days</CardTitle>
                    <CardDescription>Consider reviewing topics studied on these days.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                    {lowFocusDays.map((date, index) => (
                        <Badge key={index} variant="destructive">
                            {format(date, 'MMM dd')}
                        </Badge>
                    ))}
                </CardContent>
            </Card>
        )}
      </CardContent>
    </Card>
  );
}
