'use client';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { StudyLog } from '@/lib/types';
import { format } from 'date-fns';
import { Icons } from '@/components/icons';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '../ui/button';
import { Timestamp } from 'firebase/firestore';

const focusVariantMap: { [key: string]: 'default' | 'secondary' | 'destructive' } = {
  High: 'default',
  Medium: 'secondary',
  Low: 'destructive',
};

const goalStatusOptions: StudyLog['goalStatus'][] = ['Completed', 'In Progress', 'Not Started'];

type StudyLogTableProps = {
  logs: StudyLog[];
  onUpdateLog: (logId: string, updatedValues: Partial<Omit<StudyLog, 'id'>>) => void;
};

const toDate = (date: Date | Timestamp): Date => {
    return date instanceof Timestamp ? date.toDate() : date;
}


export function StudyLogTable({ logs, onUpdateLog }: StudyLogTableProps) {
  const sortedLogs = [...logs].sort((a, b) => toDate(b.date).getTime() - toDate(a.date).getTime());

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline">Study Log</CardTitle>
        <CardDescription>A detailed record of your study sessions.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="max-h-[500px] overflow-auto">
            <Table>
            <TableHeader className="sticky top-0 bg-card">
                <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead className="text-right">Time (min)</TableHead>
                <TableHead>Focus</TableHead>
                <TableHead>Mood</TableHead>
                <TableHead>Goal</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {sortedLogs.length > 0 ? (
                sortedLogs.map((log) => (
                    <TableRow key={log.id}>
                    <TableCell className="font-medium">{format(toDate(log.date), 'MMM dd, yyyy')}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: log.subjectColor }} />
                        {log.subjectName}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{log.timeSpent}</TableCell>
                    <TableCell>
                        <Badge variant={focusVariantMap[log.focusLevel] || 'secondary'}>
                        {log.focusLevel}
                        </Badge>
                    </TableCell>
                    <TableCell>{log.mood}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm" className="w-[120px] justify-between">
                            {log.goalStatus} <Icons.ChevronDown className="ml-2 h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuRadioGroup
                            value={log.goalStatus}
                            onValueChange={(value) =>
                              onUpdateLog(log.id, { goalStatus: value as StudyLog['goalStatus'] })
                            }
                          >
                            {goalStatusOptions.map((status) => (
                              <DropdownMenuRadioItem key={status} value={status}>
                                {status}
                              </DropdownMenuRadioItem>
                            ))}
                          </DropdownMenuRadioGroup>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                    </TableRow>
                ))
                ) : (
                <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                    No logs found for the selected period.
                    </TableCell>
                </TableRow>
                )}
            </TableBody>
            </Table>
        </div>
      </CardContent>
    </Card>
  );
}
