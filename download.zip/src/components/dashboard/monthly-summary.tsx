'use client';

import { useState, useMemo, startTransition } from 'react';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { getAISuggestions, getMonthlySummary } from '@/lib/actions';
import type { StudyLog } from '@/lib/types';
import { Icons } from '@/components/icons';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100,
    },
  },
};

export function MonthlySummary({ logs }: { logs: StudyLog[] }) {
  const [summary, setSummary] = useState('');
  const [suggestions, setSuggestions] = useState('');
  const [isSummaryLoading, setIsSummaryLoading] = useState(false);
  const [isSuggestionsLoading, setIsSuggestionsLoading] = useState(false);
  
  const stats = useMemo(() => {
    const totalTime = logs.reduce((acc, log) => acc + log.timeSpent, 0);
    const focusMapping = { Low: 1, Medium: 2, High: 3 };
    const totalFocus = logs.reduce((acc, log) => acc + focusMapping[log.focusLevel], 0);
    const averageFocus = logs.length > 0 ? (totalFocus / logs.length).toFixed(1) : 'N/A';
    const goalsCompleted = logs.filter(log => log.goalStatus === 'Completed').length;
    
    return {
      totalHours: (totalTime / 60).toFixed(1),
      totalSessions: logs.length,
      averageFocus,
      goalsCompleted
    };
  }, [logs]);

  const handleGetSummary = () => {
    setIsSummaryLoading(true);
    startTransition(() => {
        getMonthlySummary(logs).then(result => {
            setSummary(result);
            setIsSummaryLoading(false);
        });
    });
  };
  
  const handleGetSuggestions = () => {
    setIsSuggestionsLoading(true);
    startTransition(() => {
        getAISuggestions(logs).then(result => {
            setSuggestions(result);
            setIsSuggestionsLoading(false);
        });
    });
  };

  return (
    <>
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Study Time</CardDescription>
            <CardTitle className="font-headline text-4xl">{stats.totalHours} hrs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Across {stats.totalSessions} sessions
            </div>
          </CardContent>
        </Card>
      </motion.div>
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Avg. Focus Level</CardDescription>
            <CardTitle className="font-headline text-4xl">{stats.averageFocus} / 3.0</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Based on your self-assessment
            </div>
          </CardContent>
        </Card>
      </motion.div>
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Goals Completed</CardDescription>
            <CardTitle className="font-headline text-4xl">{stats.goalsCompleted}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Keep up the great work!
            </div>
          </CardContent>
        </Card>
      </motion.div>
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader>
            <CardTitle className="font-headline text-xl">AI Insights</CardTitle>
            <CardDescription>Get personalized feedback on your study habits.</CardDescription>
          </CardHeader>
          <CardContent>
            {isSummaryLoading ? (
              <Skeleton className="h-20 w-full" />
            ) : summary ? (
              <Alert>
                <Icons.Bot className="h-4 w-4" />
                <AlertTitle>Monthly Summary</AlertTitle>
                <AlertDescription>{summary}</AlertDescription>
              </Alert>
            ) : null}

            {isSuggestionsLoading ? (
              <Skeleton className="mt-2 h-20 w-full" />
            ) : suggestions ? (
              <Alert className="mt-2">
                <Icons.Bot className="h-4 w-4" />
                <AlertTitle>Improvement Suggestions</AlertTitle>
                <AlertDescription>{suggestions}</AlertDescription>
              </Alert>
            ) : null}
          </CardContent>
          <CardFooter className="flex-col items-start gap-2">
            <Button onClick={handleGetSummary} disabled={isSummaryLoading || logs.length === 0} size="sm" variant="outline">
              {isSummaryLoading ? <Icons.Clock className="mr-2 h-4 w-4 animate-spin" /> : <Icons.FileText className="mr-2 h-4 w-4" />}
              Generate Summary
            </Button>
            <Button onClick={handleGetSuggestions} disabled={isSuggestionsLoading || logs.length === 0} size="sm" variant="outline">
              {isSuggestionsLoading ? <Icons.Clock className="mr-2 h-4 w-4 animate-spin" /> : <Icons.Sparkles className="mr-2 h-4 w-4" />}
              Get Suggestions
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </>
  );
}
