'use client';

import { useMemo } from 'react';
import type { StudyLog, WeeklyGoal, Subject } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { startOfWeek, endOfWeek, isWithinInterval } from 'date-fns';
import { Timestamp } from 'firebase/firestore';

interface WeeklyGoalsProps {
  studyLogs: StudyLog[];
  weeklyGoals: WeeklyGoal[];
  subjects: Subject[];
}

const toDate = (date: Date | Timestamp): Date => {
  return date instanceof Timestamp ? date.toDate() : date;
};

export function WeeklyGoals({ studyLogs, weeklyGoals, subjects }: WeeklyGoalsProps) {
  const currentWeekProgress = useMemo(() => {
    const today = new Date();
    const weekStart = startOfWeek(today, { weekStartsOn: 1 }); // Monday
    const weekEnd = endOfWeek(today, { weekStartsOn: 1 });

    const currentWeekGoals = weeklyGoals.filter(goal => {
        const goalDate = toDate(goal.weekStartDate);
        return goalDate.getTime() === weekStart.getTime();
    });

    if (currentWeekGoals.length === 0) {
      return [];
    }

    const currentWeekLogs = studyLogs.filter(log => {
      const logDate = toDate(log.date);
      return isWithinInterval(logDate, { start: weekStart, end: weekEnd });
    });

    return currentWeekGoals.map(goal => {
      const subject = subjects.find(s => s.id === goal.subjectId);
      const relevantLogs = currentWeekLogs.filter(log => log.subjectId === goal.subjectId);
      const timeSpent = relevantLogs.reduce((acc, log) => acc + log.timeSpent, 0);
      const progress = Math.min((timeSpent / goal.targetTime) * 100, 100);

      return {
        subjectName: subject?.name || 'Unknown Subject',
        subjectColor: subject?.color || '#808080',
        targetTime: goal.targetTime,
        timeSpent,
        progress,
      };
    });
  }, [studyLogs, weeklyGoals, subjects]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline">This Week's Goals</CardTitle>
        <CardDescription>Your progress towards your weekly study targets.</CardDescription>
      </CardHeader>
      <CardContent>
        {currentWeekProgress.length > 0 ? (
          <div className="space-y-4">
            {currentWeekProgress.map(goal => (
              <div key={goal.subjectName}>
                <div className="flex justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="h-3 w-3 rounded-full" style={{ backgroundColor: goal.subjectColor }} />
                    <span className="font-medium text-sm">{goal.subjectName}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {Math.round(goal.timeSpent)} / {goal.targetTime} min
                  </span>
                </div>
                <Progress value={goal.progress} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-muted-foreground py-8">
            You haven't set any goals for this week.
            <br />
            Go to the 'Goals' page to set your targets!
          </div>
        )}
      </CardContent>
    </Card>
  );
}
