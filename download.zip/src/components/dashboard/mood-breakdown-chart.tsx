'use client';

import { useMemo } from 'react';
import { Pie, PieChart, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import type { StudyLog } from '@/lib/types';

const chartConfig = {
  Happy: {
    label: 'Happy',
    color: 'hsl(var(--chart-1))',
  },
  Neutral: {
    label: 'Neutral',
    color: 'hsl(var(--chart-2))',
  },
  Sad: {
    label: 'Sad',
    color: 'hsl(var(--chart-3))',
  },
  Stressed: {
    label: 'Stressed',
    color: 'hsl(var(--chart-4))',
  },
  Productive: {
    label: 'Productive',
    color: 'hsl(var(--chart-5))',
  },
} satisfies ChartConfig;

export function MoodBreakdownChart({ logs }: { logs: StudyLog[] }) {
  const chartData = useMemo(() => {
    const moodCounts = logs.reduce((acc, log) => {
      acc[log.mood] = (acc[log.mood] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    return Object.entries(moodCounts).map(([name, value]) => ({ name, value, fill: `var(--color-${name})` }));
  }, [logs]);

  return (
    <Card className="lg:col-span-3">
      <CardHeader>
        <CardTitle className="font-headline">Mood Breakdown</CardTitle>
        <CardDescription>Your emotional state during study sessions.</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="min-h-[350px] w-full">
            {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={350}>
                    <PieChart>
                        <ChartTooltip
                            content={<ChartTooltipContent hideLabel nameKey="name"/>}
                        />
                        <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={120}
                        dataKey="value"
                        nameKey="name"
                        strokeWidth={2}
                        >
                        {chartData.map((entry) => (
                            <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                        ))}
                        </Pie>
                        <Legend
                            iconType="circle"
                            wrapperStyle={{
                                paddingTop: '20px',
                                fontSize: '12px'
                            }}
                        />
                    </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                    No mood data to display.
                </div>
            )}
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
