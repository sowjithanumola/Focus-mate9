'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { AddStudyLogDialog } from '@/components/dashboard/add-study-log-dialog';
import {
  useUser,
  useFirestore,
  useCollection,
  useMemoFirebase,
  addDocumentNonBlocking,
} from '@/firebase';
import { collection } from 'firebase/firestore';
import type { Subject, StudyLog } from '@/lib/types';
import { toast } from '@/hooks/use-toast';
import { Icons } from '@/components/icons';
import { v4 as uuidv4 } from 'uuid';
import { Timestamp } from 'firebase/firestore';

const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export default function TimerPage() {
  const { user } = useUser();
  const firestore = useFirestore();
  
  const subjectsCollection = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'users', user.uid, 'subjects');
  }, [firestore, user]);
  
  const { data: subjects, isLoading: areSubjectsLoading } = useCollection<Subject>(subjectsCollection);

  const [sessionLength, setSessionLength] = useState(25); // in minutes
  const [timeLeft, setTimeLeft] = useState(sessionLength * 60);
  const [isActive, setIsActive] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [isLogDialogOpen, setIsLogDialogOpen] = useState(false);
  const [logToAdd, setLogToAdd] = useState<Omit<StudyLog, 'id' | 'userId'> | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      audioRef.current = new Audio('/sounds/notification.mp3');
    }
  }, []);
  
  useEffect(() => {
    setTimeLeft(sessionLength * 60);
  }, [sessionLength]);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setTimeout(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      handleTimerEnd();
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleTimerEnd = () => {
    setIsActive(false);
    if (audioRef.current) {
        audioRef.current.play();
    }
    toast({
        title: "Session Complete!",
        description: "Time to log your study session.",
    });

    if (selectedSubject) {
      setLogToAdd({
        date: new Date(),
        subjectId: selectedSubject.id,
        subjectName: selectedSubject.name,
        subjectColor: selectedSubject.color,
        timeSpent: sessionLength,
        focusLevel: 'Medium',
        mood: 'Productive',
        goalStatus: 'In Progress',
        remarks: 'Completed a focused study session.'
      });
      setIsLogDialogOpen(true);
    }
  };

  const handleStartPause = () => {
    if (!selectedSubject) {
      toast({
        variant: 'destructive',
        title: 'No Subject Selected',
        description: 'Please select a subject before starting the timer.',
      });
      return;
    }
    setIsActive(!isActive);
  };

  const handleReset = () => {
    setIsActive(false);
    setTimeLeft(sessionLength * 60);
  };

  const handleAddLog = (newLog: Omit<StudyLog, 'id' | 'userId'>) => {
    if (!user) return;
    const studyLogsCollection = collection(firestore, 'users', user.uid, 'studyLogs');
    const logWithTimestamp = {
      ...newLog,
      id: uuidv4(),
      userId: user.uid,
      date: Timestamp.fromDate(newLog.date as Date),
    };
    addDocumentNonBlocking(studyLogsCollection, logWithTimestamp);
    setLogToAdd(null);
  };

  const radius = 140;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (timeLeft / (sessionLength * 60)) * circumference;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center justify-center space-y-8"
      >
        <div className="text-center">
          <h1 className="font-headline text-3xl font-bold tracking-tight">Study Timer</h1>
          <p className="text-muted-foreground">Focus on your work with the Pomodoro technique.</p>
        </div>

        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Session Settings</CardTitle>
            <CardDescription>Configure your study session.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-sm font-medium">Subject</label>
                    <Select
                        onValueChange={(value) => {
                            const subject = subjects?.find(s => s.id === value);
                            setSelectedSubject(subject || null);
                        }}
                        disabled={isActive || areSubjectsLoading}
                    >
                        <SelectTrigger>
                            <SelectValue placeholder="Select a subject" />
                        </SelectTrigger>
                        <SelectContent>
                        {areSubjectsLoading ? (
                            <SelectItem value="loading" disabled>Loading...</SelectItem>
                        ) : (
                            subjects?.map(subject => (
                            <SelectItem key={subject.id} value={subject.id}>
                                <div className="flex items-center gap-2">
                                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: subject.color }} />
                                {subject.name}
                                </div>
                            </SelectItem>
                            ))
                        )}
                        </SelectContent>
                    </Select>
                </div>
                 <div>
                    <label htmlFor="session-length" className="text-sm font-medium">Duration (minutes)</label>
                    <Input
                        id="session-length"
                        type="number"
                        value={sessionLength}
                        onChange={(e) => setSessionLength(parseInt(e.target.value))}
                        disabled={isActive}
                    />
                 </div>
            </div>
          </CardContent>
        </Card>

        <motion.div className="relative h-80 w-80"
             initial={{ scale: 0.8 }}
             animate={{ scale: 1 }}
             transition={{ type: 'spring' }}
        >
          <svg className="h-full w-full" viewBox="0 0 300 300">
            <circle
              stroke="hsl(var(--border))"
              fill="transparent"
              strokeWidth="10"
              r={radius}
              cx="150"
              cy="150"
            />
            <motion.circle
              stroke="hsl(var(--primary))"
              fill="transparent"
              strokeWidth="10"
              strokeLinecap="round"
              r={radius}
              cx="150"
              cy="150"
              transform="rotate(-90 150 150)"
              style={{ strokeDasharray: circumference, strokeDashoffset }}
              transition={{ duration: 1, ease: 'linear' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="font-mono text-6xl font-bold tracking-tighter">
              {formatTime(timeLeft)}
            </div>
             <div className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                {selectedSubject ? (
                    <>
                        <span className="h-2 w-2 rounded-full" style={{backgroundColor: selectedSubject.color}} />
                        {selectedSubject.name}
                    </>
                ) : "No Subject"}
            </div>
          </div>
        </motion.div>

        <div className="flex items-center gap-4">
          <Button onClick={handleStartPause} size="lg" className="w-32">
            {isActive ? 'Pause' : 'Start'}
          </Button>
          <Button onClick={handleReset} variant="outline" size="lg">
            Reset
          </Button>
        </div>
      </motion.div>

      {logToAdd && (
        <AddStudyLogDialog
          open={isLogDialogOpen}
          onOpenChange={setIsLogDialogOpen}
          subjects={subjects || []}
          onAddLog={handleAddLog}
          initialValues={logToAdd}
        >
            <></>
        </AddStudyLogDialog>
      )}
    </>
  );
}
