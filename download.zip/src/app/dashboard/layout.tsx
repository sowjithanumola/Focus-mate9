'use client';

import { Header } from "@/components/dashboard/header";
import { ChatWidget } from "@/components/dashboard/chat-widget";
import { useUser } from "@/firebase";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Icons } from "@/components/icons";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, isUserLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [user, isUserLoading, router]);

  if (isUserLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Icons.Clock className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // Only render children if the user is authenticated and loading is complete
  if (!user) {
    return null; // or a loading/redirecting state
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        {children}
      </main>
      <footer className="p-4 text-center text-sm text-muted-foreground md:p-8">
        © 2025 Sowjith Anumola. All rights reserved.
      </footer>
      <ChatWidget />
    </div>
  );
}
