
'use client';

import React, { useState, useMemo, startTransition } from 'react';
import { motion } from 'framer-motion';
import {
  useUser,
  useFirestore,
  useCollection,
  useMemoFirebase,
  addDocumentNonBlocking,
} from '@/firebase';
import { collection, query, where, Timestamp }from 'firebase/firestore';
import type { StudyLog, MonthlyReport, Subject } from '@/lib/types';
import { getMonth, getYear, startOfMonth, endOfMonth, format } from 'date-fns';
import { v4 as uuidv4 } from 'uuid';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Icons } from '@/components/icons';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  generateAndSaveMonthlyReport,
  getReportForMonth,
} from '@/lib/actions';
import { ReportDisplay } from '@/components/dashboard/reports/report-display';
import { Skeleton } from '@/components/ui/skeleton';
import { toDate } from '@/lib/utils';

const months = Array.from({ length: 12 }, (_, i) => ({
  value: i,
  label: format(new Date(0, i), 'MMMM'),
}));
const years = Array.from({ length: 5 }, (_, i) => getYear(new Date()) - i);

export default function ReportsPage() {
  const { user } = useUser();
  const firestore = useFirestore();

  const [selectedMonth, setSelectedMonth] = useState<number>(getMonth(new Date()));
  const [selectedYear, setSelectedYear] = useState<number>(getYear(new Date()));
  const [report, setReport] = useState<MonthlyReport | null | undefined>(undefined); // undefined: not checked, null: not found
  const [isLoading, setIsLoading] = useState(false);

  const monthStart = useMemo(
    () => startOfMonth(new Date(selectedYear, selectedMonth)),
    [selectedMonth, selectedYear]
  );
  const monthEnd = useMemo(
    () => endOfMonth(new Date(selectedYear, selectedMonth)),
    [selectedMonth, selectedYear]
  );
  const monthStartTimestamp = useMemo(() => Timestamp.fromDate(monthStart), [monthStart]);
  const monthEndTimestamp = useMemo(() => Timestamp.fromDate(monthEnd), [monthEnd]);
  
  const studyLogsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(firestore, 'users', user.uid, 'studyLogs'),
      where('date', '>=', monthStartTimestamp),
      where('date', '<=', monthEndTimestamp)
    );
  }, [firestore, user, monthStartTimestamp, monthEndTimestamp]);

  const { data: studyLogs, isLoading: areStudyLogsLoading } = useCollection<StudyLog>(studyLogsQuery);

  const handleFetchReport = async () => {
    if (!user) return;
    setIsLoading(true);
    const existingReport = await getReportForMonth(user.uid, selectedMonth + 1, selectedYear);
    setReport(existingReport);
    setIsLoading(false);
  };

  const handleGenerateReport = () => {
    if (!user || !studyLogs) return;
    setIsLoading(true);
    
    // Convert Timestamps to strings before sending to the server action
    const serializableLogs = studyLogs.map(log => ({
        ...log,
        date: toDate(log.date).toISOString(),
    }));

    startTransition(() => {
        generateAndSaveMonthlyReport(user.uid, selectedMonth + 1, selectedYear, serializableLogs).then(newReport => {
            setReport(newReport);
            setIsLoading(false);
        });
    });
  };

  const reportId = report ? report.id : `${user?.uid}_${selectedYear}_${selectedMonth + 1}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-headline text-3xl font-bold tracking-tight">
            Monthly Reports
          </h1>
          <p className="text-muted-foreground">
            Generate and view AI-powered summaries of your study progress.
          </p>
        </div>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Select a Period</CardTitle>
          <CardDescription>
            Choose the month and year you want to view or generate a report for.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-4">
          <Select
            value={String(selectedMonth)}
            onValueChange={(val) => setSelectedMonth(Number(val))}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Month" />
            </SelectTrigger>
            <SelectContent>
              {months.map(m => (
                <SelectItem key={m.value} value={String(m.value)}>
                  {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={String(selectedYear)}
            onValueChange={(val) => setSelectedYear(Number(val))}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              {years.map(y => (
                <SelectItem key={y} value={String(y)}>
                  {y}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={handleFetchReport} disabled={isLoading || areStudyLogsLoading}>
            <Icons.Search className="mr-2 h-4 w-4" />
            View Report
          </Button>
          <Button onClick={handleGenerateReport} disabled={isLoading || areStudyLogsLoading || !studyLogs || studyLogs.length === 0}>
             {isLoading ? <Icons.Clock className="mr-2 h-4 w-4 animate-spin" /> : <Icons.Sparkles className="mr-2 h-4 w-4" />}
            Generate New Report
          </Button>
        </CardContent>
      </Card>

      {isLoading && (
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
          </CardContent>
        </Card>
      )}

      {!isLoading && report !== undefined && (
        <ReportDisplay 
            report={report} 
            studyLogs={studyLogs || []} 
            month={selectedMonth} 
            year={selectedYear} 
        />
      )}
    </motion.div>
  );
}
