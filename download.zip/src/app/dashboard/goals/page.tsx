'use client';

import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  useUser,
  useFirestore,
  useCollection,
  useMemoFirebase,
  setDocumentNonBlocking,
} from '@/firebase';
import { collection, query, where, Timestamp, doc } from 'firebase/firestore';
import type { Subject, WeeklyGoal } from '@/lib/types';
import { startOfWeek } from 'date-fns';
import { v4 as uuidv4 } from 'uuid';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Icons } from '@/components/icons';
import { toast } from '@/hooks/use-toast';

export default function GoalsPage() {
  const { user } = useUser();
  const firestore = useFirestore();

  const subjectsCollection = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'users', user.uid, 'subjects');
  }, [firestore, user]);

  const { data: subjects, isLoading: areSubjectsLoading } = useCollection<Subject>(subjectsCollection);

  const currentWeekStart = useMemo(() => startOfWeek(new Date(), { weekStartsOn: 1 }), []);
  const currentWeekGoalsQuery = useMemoFirebase(() => {
    if (!user) return null;
    const weekStartTimestamp = Timestamp.fromDate(currentWeekStart);
    return query(
      collection(firestore, 'users', user.uid, 'weeklyGoals'),
      where('weekStartDate', '==', weekStartTimestamp)
    );
  }, [firestore, user, currentWeekStart]);

  const { data: weeklyGoals, isLoading: areWeeklyGoalsLoading } = useCollection<WeeklyGoal>(currentWeekGoalsQuery);

  const [targetTimes, setTargetTimes] = useState<Record<string, number>>({});

  React.useEffect(() => {
    if (weeklyGoals) {
      const initialTimes = weeklyGoals.reduce((acc, goal) => {
        acc[goal.subjectId] = goal.targetTime;
        return acc;
      }, {} as Record<string, number>);
      setTargetTimes(initialTimes);
    }
  }, [weeklyGoals]);

  const handleTimeChange = (subjectId: string, value: number) => {
    setTargetTimes(prev => ({ ...prev, [subjectId]: value }));
  };

  const handleSaveGoals = () => {
    if (!user || !subjects) return;

    const weekStartTimestamp = Timestamp.fromDate(currentWeekStart);

    subjects.forEach(subject => {
      const targetTime = targetTimes[subject.id] || 0;
      const existingGoal = weeklyGoals?.find(g => g.subjectId === subject.id);
      
      const goalData: Omit<WeeklyGoal, 'id'> = {
        userId: user.uid,
        subjectId: subject.id,
        weekStartDate: weekStartTimestamp,
        targetTime: targetTime,
      };

      const goalId = existingGoal ? existingGoal.id : `${user.uid}_${subject.id}_${currentWeekStart.getTime()}`;
      
      setDocumentNonBlocking(
        doc(firestore, 'users', user.uid, 'weeklyGoals', goalId), 
        { id: goalId, ...goalData }, 
        { merge: true }
      );
    });
    
    toast({
        title: "Goals Saved!",
        description: "Your weekly study goals have been updated.",
    });
  };

  if (areSubjectsLoading || areWeeklyGoalsLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Icons.Clock className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-headline text-3xl font-bold tracking-tight">
            Weekly Goals
          </h1>
          <p className="text-muted-foreground">
            Set your study time targets for each subject this week.
          </p>
        </div>
        <Button onClick={handleSaveGoals}>
          <Icons.CheckCircle className="mr-2 h-4 w-4" />
          Save Goals
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Set Your Targets</CardTitle>
          <CardDescription>
            Use the sliders to set how many minutes you want to study for each subject.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {subjects && subjects.length > 0 ? (
            subjects.map(subject => (
              <div key={subject.id} className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 font-medium">
                    <span
                      className="h-3 w-3 rounded-full"
                      style={{ backgroundColor: subject.color }}
                    />
                    {subject.name}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-4 items-center">
                   <Slider
                    value={[targetTimes[subject.id] || 0]}
                    onValueChange={([value]) => handleTimeChange(subject.id, value)}
                    max={600}
                    step={15}
                  />
                  <div className="flex items-center gap-2">
                    <Input
                        type="number"
                        className="w-24"
                        value={targetTimes[subject.id] || 0}
                        onChange={(e) => handleTimeChange(subject.id, parseInt(e.target.value) || 0)}
                        step={15}
                    />
                    <span className="text-muted-foreground">minutes</span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-muted-foreground py-8">
              You need to add some subjects before you can set goals.
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
