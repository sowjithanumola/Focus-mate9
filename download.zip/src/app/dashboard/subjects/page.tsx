'use client';

import React, { useState, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Icons } from '@/components/icons';
import type { Subject } from '@/lib/types';
import {
  useUser,
  useFirestore,
  useCollection,
  useMemoFirebase,
  addDocumentNonBlocking,
  updateDocumentNonBlocking,
  deleteDocumentNonBlocking,
} from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';
import { toast } from '@/hooks/use-toast';

const subjectSchema = z.object({
  name: z.string().min(2, { message: 'Subject name is required.' }),
  color: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/, { message: 'Please enter a valid hex color.' }),
});

const defaultColors = [
  "#87CEEB", "#468499", "#FFC0CB", "#FFA07A", "#20B2AA", 
  "#9370DB", "#3CB371", "#FFD700", "#F08080", "#778899"
];

export default function SubjectsPage() {
  const { user } = useUser();
  const firestore = useFirestore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  const subjectsCollection = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'users', user.uid, 'subjects');
  }, [firestore, user]);

  const { data: subjects, isLoading } = useCollection<Subject>(
    subjectsCollection
  );

  const form = useForm<z.infer<typeof subjectSchema>>({
    resolver: zodResolver(subjectSchema),
    defaultValues: {
      name: '',
      color: defaultColors[0],
    },
  });

  const handleOpenDialog = (subject: Subject | null = null) => {
    setEditingSubject(subject);
    if (subject) {
      form.reset({ name: subject.name, color: subject.color });
    } else {
      const usedColors = subjects?.map(s => s.color) || [];
      const availableColor = defaultColors.find(c => !usedColors.includes(c)) || `#${Math.floor(Math.random()*16777215).toString(16).padStart(6, '0')}`;
      form.reset({ name: '', color: availableColor });
    }
    setIsDialogOpen(true);
  };

  const handleDelete = (subjectId: string) => {
    if (!user) return;
    const subjectRef = doc(firestore, 'users', user.uid, 'subjects', subjectId);
    deleteDocumentNonBlocking(subjectRef);
    toast({
        title: "Subject Deleted",
        description: "The subject has been successfully removed.",
    });
  };

  const onSubmit = (values: z.infer<typeof subjectSchema>) => {
    if (!user || !subjectsCollection) return;

    if (editingSubject) {
      // Update existing subject
      const subjectRef = doc(firestore, 'users', user.uid, 'subjects', editingSubject.id);
      updateDocumentNonBlocking(subjectRef, values);
      toast({
        title: 'Subject Updated',
        description: 'Your subject has been updated successfully.',
      });
    } else {
      // Add new subject
      const newSubject: Omit<Subject, 'id'> = {
        userId: user.uid,
        name: values.name,
        color: values.color,
      };
      addDocumentNonBlocking(subjectsCollection, { id: uuidv4(), ...newSubject });
      toast({
        title: 'Subject Added',
        description: 'A new subject has been added to your list.',
      });
    }
    setIsDialogOpen(false);
    setEditingSubject(null);
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Icons.Clock className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-headline text-3xl font-bold tracking-tight">
            Manage Subjects
          </h1>
          <p className="text-muted-foreground">
            Add, edit, or delete your study subjects here.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Icons.Add className="mr-2 h-4 w-4" />
              Add Subject
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-headline">
                {editingSubject ? 'Edit Subject' : 'Add New Subject'}
              </DialogTitle>
              <DialogDescription>
                {editingSubject ? 'Update the details for your subject.' : 'Add a new subject to track in your study logs.'}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(onSubmit)}
                className="space-y-4"
              >
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Quantum Physics" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="color"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Color</FormLabel>
                      <FormControl>
                        <div className="flex items-center gap-2">
                           <Input type="color" className="w-12 h-10 p-1" {...field} />
                           <Input type="text" placeholder="#87CEEB" {...field} />
                        </div>
                      </FormControl>
                       <div className="flex flex-wrap gap-2 mt-2">
                        {defaultColors.map(color => (
                            <Button
                            type="button"
                            key={color}
                            className="h-6 w-6 rounded-full border"
                            style={{ backgroundColor: color }}
                            onClick={() => form.setValue('color', color, { shouldValidate: true })}
                            />
                        ))}
                        </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="submit">
                    {editingSubject ? 'Save Changes' : 'Add Subject'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Subjects</CardTitle>
          <CardDescription>
            A list of all your current study subjects.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Color</TableHead>
                <TableHead>Subject Name</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {subjects && subjects.length > 0 ? (
                subjects.map((subject) => (
                  <TableRow key={subject.id}>
                    <TableCell>
                      <div
                        className="h-6 w-6 rounded-full border"
                        style={{ backgroundColor: subject.color }}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{subject.name}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleOpenDialog(subject)}
                      >
                        <Icons.Settings className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => handleDelete(subject.id)}
                      >
                        <Icons.XCircle className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={3} className="h-24 text-center">
                    No subjects added yet.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </motion.div>
  );
}
