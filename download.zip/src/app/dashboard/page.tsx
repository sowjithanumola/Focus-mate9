'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { AddStudyLogDialog } from '@/components/dashboard/add-study-log-dialog';
import { StudyLogTable } from '@/components/dashboard/study-log-table';
import { MonthlySummary } from '@/components/dashboard/monthly-summary';
import { WeeklyGoals } from '@/components/dashboard/weekly-goals';
import { FocusVsTimeChart } from '@/components/dashboard/focus-vs-time-chart';
import { MoodBreakdownChart } from '@/components/dashboard/mood-breakdown-chart';
import { Button } from '@/components/ui/button';
import { Icons } from '@/components/icons';
import type { StudyLog, Subject, WeeklyGoal } from '@/lib/types';
import { DatePickerWithRange } from '@/components/dashboard/date-picker-with-range';
import type { DateRange } from 'react-day-picker';
import { startOfMonth, endOfMonth } from 'date-fns';
import {
  useUser,
  useFirestore,
  useCollection,
  useMemoFirebase,
  addDocumentNonBlocking,
  updateDocumentNonBlocking,
} from '@/firebase';
import { collection, doc, Timestamp } from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100,
    },
  },
};

export default function DashboardPage() {
  const router = useRouter();
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const defaultDateRange: DateRange = {
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  };
  const [date, setDate] = useState<DateRange | undefined>(defaultDateRange);

  const studyLogsCollection = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'users', user.uid, 'studyLogs');
  }, [firestore, user]);

  const subjectsCollection = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'users', user.uid, 'subjects');
  }, [firestore, user]);

   const weeklyGoalsCollection = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'users', user.uid, 'weeklyGoals');
  }, [firestore, user]);

  const { data: studyLogs, isLoading: areStudyLogsLoading } = useCollection<StudyLog>(studyLogsCollection);
  const { data: subjects, isLoading: areSubjectsLoading } = useCollection<Subject>(subjectsCollection);
  const { data: weeklyGoals, isLoading: areWeeklyGoalsLoading } = useCollection<WeeklyGoal>(weeklyGoalsCollection);

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [user, isUserLoading, router]);

  const handleAddLog = (newLog: Omit<StudyLog, 'id' | 'userId'>) => {
    if (!studyLogsCollection || !user) return;
    const logWithTimestamp = {
      ...newLog,
      id: uuidv4(),
      userId: user.uid,
      date: Timestamp.fromDate(newLog.date as Date),
    };
    addDocumentNonBlocking(studyLogsCollection, logWithTimestamp);
  };

  const handleUpdateLog = (logId: string, updatedValues: Partial<Omit<StudyLog, 'id'>>) => {
    if (!user) return;
    const logRef = doc(firestore, 'users', user.uid, 'studyLogs', logId);
    updateDocumentNonBlocking(logRef, updatedValues);
  };

  const filteredLogs = useMemo(() => {
    if (!studyLogs) return [];
    if (!date?.from) return studyLogs;
    const fromDate = date.from;
    const toDate = date.to ?? fromDate;

    return studyLogs.filter(log => {
      const logDate = log.date instanceof Timestamp ? log.date.toDate() : new Date(log.date);
      return logDate >= fromDate && logDate <= toDate;
    });
  }, [studyLogs, date]);

  if (isUserLoading || areStudyLogsLoading || areSubjectsLoading || areWeeklyGoalsLoading) {
    return (
        <div className="flex h-full w-full items-center justify-center">
            <Icons.Clock className="h-8 w-8 animate-spin" />
        </div>
    )
  }

  return (
    <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h1 className="font-headline text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Here&apos;s a summary of your study performance.
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <DatePickerWithRange date={date} setDate={setDate} />
          <AddStudyLogDialog subjects={subjects || []} onAddLog={handleAddLog}>
            <Button>
              <Icons.Add className="mr-2 h-4 w-4" />
              Add Log
            </Button>
          </AddStudyLogDialog>
        </div>
      </div>
      <motion.div
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <MonthlySummary logs={filteredLogs} />
      </motion.div>
      <motion.div variants={itemVariants}>
          <WeeklyGoals
            studyLogs={studyLogs || []}
            weeklyGoals={weeklyGoals || []}
            subjects={subjects || []}
          />
        </motion.div>
      <motion.div
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-7"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="lg:col-span-4">
          <FocusVsTimeChart logs={filteredLogs} />
        </motion.div>
        <motion.div variants={itemVariants} className="lg:col-span-3">
          <MoodBreakdownChart logs={filteredLogs} />
        </motion.div>
      </motion.div>
      <motion.div variants={itemVariants}>
        <StudyLogTable logs={filteredLogs} onUpdateLog={handleUpdateLog} />
      </motion.div>
    </>
  );
}
