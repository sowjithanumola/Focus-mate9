import type { StudyLog } from './types';

// This file is no longer the primary source of data and will be removed in a future step.
// The dashboard now fetches data from Firebase.
export const mockStudyLogs: StudyLog[] = [];
