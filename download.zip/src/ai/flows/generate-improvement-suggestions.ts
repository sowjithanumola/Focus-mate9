'use server';

/**
 * @fileOverview This file defines a Genkit flow to analyze monthly study data and provide personalized improvement suggestions.
 *
 * - generateImprovementSuggestions - A function that generates personalized study improvement suggestions.
 * - ImprovementSuggestionsInput - The input type for the generateImprovementSuggestions function.
 * - ImprovementSuggestionsOutput - The return type for the generateImprovementSuggestions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ImprovementSuggestionsInputSchema = z.object({
  monthlyData: z.string().describe('The user\'s monthly study data, including time spent, focus level, mood, and goal status.'),
});
export type ImprovementSuggestionsInput = z.infer<typeof ImprovementSuggestionsInputSchema>;

const ImprovementSuggestionsOutputSchema = z.object({
  suggestions: z.string().describe('Personalized, actionable suggestions for improving study habits, presented in a friendly and encouraging tone.'),
});
export type ImprovementSuggestionsOutput = z.infer<typeof ImprovementSuggestionsOutputSchema>;

export async function generateImprovementSuggestions(
  input: ImprovementSuggestionsInput
): Promise<ImprovementSuggestionsOutput> {
  return generateImprovementSuggestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'improvementSuggestionsPrompt',
  input: {schema: ImprovementSuggestionsInputSchema},
  output: {schema: ImprovementSuggestionsOutputSchema},
  prompt: `You are an AI study coach, tasked with analyzing a student's monthly study data to provide personalized, encouraging, and actionable suggestions for improvement.

  **Analyze the following data:**
  \`\`\`json
  {{monthlyData}}
  \`\`\`

  **Your Task:**
  Based on the data, provide 2-3 specific, actionable, and positive suggestions. Frame your advice to be encouraging and supportive. Focus on practical strategies for time management, focus enhancement, mood improvement during study sessions, and goal achievement. Format the output as a single string.`,
});

const generateImprovementSuggestionsFlow = ai.defineFlow(
  {
    name: 'generateImprovementSuggestionsFlow',
    inputSchema: ImprovementSuggestionsInputSchema,
    outputSchema: ImprovementSuggestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
