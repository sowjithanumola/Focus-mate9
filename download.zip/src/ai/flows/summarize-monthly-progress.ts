'use server';

/**
 * @fileOverview Summarizes the user's monthly progress, highlighting key achievements and areas for improvement.
 *
 * - summarizeMonthlyProgress - A function that generates a summary of the monthly progress.
 * - SummarizeMonthlyProgressInput - The input type for the summarizeMonthlyProgress function.
 * - SummarizeMonthlyProgressOutput - The return type for the summarizeMonthlyProgress function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeMonthlyProgressInputSchema = z.object({
  monthlyData: z.string().describe('The user\u2019s monthly study data in JSON format, including date, subject, time spent, focus level, mood, goal status, and remarks.'),
});

export type SummarizeMonthlyProgressInput = z.infer<
  typeof SummarizeMonthlyProgressInputSchema
>;

const SummarizeMonthlyProgressOutputSchema = z.object({
  summary: z.string().describe('A concise, encouraging summary of the user\u2019s monthly progress, highlighting key achievements and positive trends.'),
});

export type SummarizeMonthlyProgressOutput = z.infer<
  typeof SummarizeMonthlyProgressOutputSchema
>;

export async function summarizeMonthlyProgress(
  input: SummarizeMonthlyProgressInput
): Promise<SummarizeMonthlyProgressOutput> {
  return summarizeMonthlyProgressFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeMonthlyProgressPrompt',
  input: {schema: SummarizeMonthlyProgressInputSchema},
  output: {schema: SummarizeMonthlyProgressOutputSchema},
  prompt: `You are an AI assistant that creates encouraging summaries of a student's monthly study progress.

  **Analyze the following data:**
  \`\`\`json
  {{{monthlyData}}}
  \`\`\`

  **Your Task:**
  Generate a short (2-3 sentences) summary. Highlight key achievements (like total study time, goals completed) and positive trends (like improved focus). Maintain a positive and motivational tone. Format the output as a single string.`,
});

const summarizeMonthlyProgressFlow = ai.defineFlow(
  {
    name: 'summarizeMonthlyProgressFlow',
    inputSchema: SummarizeMonthlyProgressInputSchema,
    outputSchema: SummarizeMonthlyProgressOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
