'use server';

/**
 * @fileOverview This file defines a Genkit flow for an educational AI tutor.
 *
 * - educationalTutor - A function that provides answers to educational questions.
 * - TutorInput - The input type for the educationalTutor function.
 * - TutorOutput - The return type for the educationalTutor function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const TutorInputSchema = z.object({
  userName: z.string().describe("The user's name."),
  question: z.string().describe("The user's question for the tutor."),
  history: z.array(z.object({
    role: z.string(),
    content: z.string(),
  })).describe('The conversation history.'),
});
export type TutorInput = z.infer<typeof TutorInputSchema>;

const TutorOutputSchema = z.object({
  answer: z.string().describe("The AI tutor's answer to the question."),
});
export type TutorOutput = z.infer<typeof TutorOutputSchema>;

export async function educationalTutor(
  input: TutorInput
): Promise<TutorOutput> {
  return educationalTutorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'educationalTutorPrompt',
  input: { schema: TutorInputSchema },
  output: { schema: TutorOutputSchema },
  prompt: `You are Focus AI, a friendly, expert, and patient AI Tutor. Your goal is to help students by providing direct answers and clear explanations. Address the user by their name, {{{userName}}}.

  When a student asks a question, first provide a clear and accurate answer. Then, follow up with a concise explanation to help them understand the underlying concepts. Use examples where helpful. Be encouraging and maintain a positive tone.

  Conversation History:
  {{#each history}}
  {{role}}: {{content}}
  {{/each}}

  User ({{{userName}}}): {{{question}}}

  Your Answer:`,
});

const educationalTutorFlow = ai.defineFlow(
  {
    name: 'educationalTutorFlow',
    inputSchema: TutorInputSchema,
    outputSchema: TutorOutputSchema,
  },
  async input => {
    const { output } = await prompt(input);
    return output!;
  }
);
