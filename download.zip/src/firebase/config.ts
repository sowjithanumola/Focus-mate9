export const firebaseConfig = {
  "projectId": "studio-2980388269-7919f",
  "appId": "1:127922542008:web:68be344638ce25186dab4d",
  "apiKey": "AIzaSyDQ6VBlZlTxHp_5_kQVBY9labNqMIDwL1o",
  "authDomain": "studio-2980388269-7919f.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "127922542008"
};
